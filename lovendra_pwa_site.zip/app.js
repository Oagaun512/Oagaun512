
function createHearts(count=40){
  const frag=document.createDocumentFragment();
  for(let i=0;i<count;i++){
    const span=document.createElement('span');
    span.className='heart';
    span.innerText='❤️';
    span.style.left=Math.random()*100+'%';
    span.style.fontSize=(24+Math.random()*36)+'px';
    span.style.animationDuration=(8+Math.random()*8)+'s';
    span.style.animationDelay=(Math.random()*8)+'s';
    frag.appendChild(span);
  }
  document.body.appendChild(frag);
}

document.addEventListener('DOMContentLoaded',()=>{
  createHearts();
  // pwa install prompt
  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('/service-worker.js');
  }
  // nav toggle
  const btn=document.getElementById('menuBtn');
  const nav=document.getElementById('mobileNav');
  if(btn){
    btn.onclick=()=>{nav.classList.toggle('hidden');};
  }
});
