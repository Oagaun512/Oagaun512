
export function initChat(){
 const log=document.getElementById('chatLog');
 const input=document.getElementById('chatInput');
 const send=document.getElementById('sendMsg');
 function add(msg,user=false){
   const div=document.createElement('div');
   div.className=user?'text-right':'text-left';
   div.innerHTML='<span class="'+(user?'bg-purple-600 text-white':'bg-gray-200')+' px-3 py-2 rounded-lg inline-block max-w-xs">'+msg+'</span>';
   log.appendChild(div);log.scrollTop=log.scrollHeight;
 }
 const replies={
  'profile':'Our Smart Profile Builder crafts bios & selects your best photos.',
  'match':'Auto‑Matchmaker delivers 1‑3 perfect matches daily.',
  'safety':'SafeMeet verifies IDs & shares live locations.',
  'pricing':'See our Pricing page for tiers.',
 };
 send.onclick=()=>{
   const msg=input.value.trim();if(!msg)return;
   add(msg,true);input.value='';
   const key=Object.keys(replies).find(k=>msg.toLowerCase().includes(k));
   const resp=key?replies[key]:"I'm still learning. Ask about profile, match, safety, or pricing.";
   setTimeout(()=>add(resp,false),500);
 };
}
