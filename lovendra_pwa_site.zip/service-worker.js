
self.addEventListener('install',e=>{self.skipWaiting();});
self.addEventListener('activate',e=>{});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET') return;
  e.respondWith(caches.open('lovendra-v1').then(async cache=>{
      const cached=await cache.match(e.request);
      if(cached) return cached;
      const res=await fetch(e.request);
      cache.put(e.request,res.clone());
      return res;
  }));
});
